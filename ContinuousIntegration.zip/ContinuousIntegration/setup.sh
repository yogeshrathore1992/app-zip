#!/bin/bash

# start the web server


cd /root/

echo "deployment start"

mkdir deployment

echo "deployment finish"
