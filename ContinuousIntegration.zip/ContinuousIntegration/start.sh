#!/bin/bash

# start the web server


cd /root/

sudo service tomcat7 restart
